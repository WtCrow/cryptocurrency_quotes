from .huobi_global import HuobiGlobal
from .okexchanges import OkCoin, OkEx
from .binance import Binance
from .bittrex import Bittrex
from .hitbtc import HitBTC
